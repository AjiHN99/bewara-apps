package com.example.bewara

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
